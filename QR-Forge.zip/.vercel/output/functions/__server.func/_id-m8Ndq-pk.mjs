import { o as __toESM } from "./_runtime.mjs";
import { t as TYPE_META } from "./_ssr/payloads-BlugSDx7.mjs";
import { i as encodeQr, t as canGenerate } from "./_ssr/encode-D9rQXfc1.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate, v as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-collection+[...].mjs";
import { y as Download } from "./_libs/lucide-react.mjs";
import { a as useCurrentUserState, r as SiteShell, t as Button } from "./_ssr/site-shell-BAvZ8sYl.mjs";
import { r as useQueryClient, t as useQuery } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as Route$1 } from "./_ssr/router-JkJchIMp.mjs";
import { i as getCode, n as deleteCode, s as saveCode } from "./_ssr/codes-WA1A9r9f.mjs";
import { a as svgToBlob, n as renderRasterBlob, o as triggerDownload, r as renderSvgString } from "./_ssr/render-NdkZar8r.mjs";
import { t as Badge } from "./_ssr/badge-CqJcIP66.mjs";
import { n as downloadFilename, t as QrPreview } from "./_ssr/qr-preview-BUJtRhpV.mjs";
import { a as upsertGuestCode, n as deleteGuestCode, r as getGuestCode } from "./_ssr/guest-store-BsRbmkuB.mjs";
import { t as Input } from "./_ssr/input-BdJvMhDZ.mjs";
import { t as Label } from "./_ssr/label-bnuyJOOq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-m8Ndq-pk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CodeDetail({ id }) {
	const { user, isPending } = useCurrentUserState();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const [name, setName] = (0, import_react.useState)(null);
	const cloud = useQuery({
		queryKey: ["code", id],
		queryFn: () => getCode({ data: id }),
		enabled: Boolean(user) && !isPending,
		retry: false
	});
	const guest = !user && !isPending ? getGuestCode(id) : void 0;
	const item = cloud.data ?? guest;
	const encoded = (0, import_react.useMemo)(() => {
		if (!item) return null;
		const valid = canGenerate(item.payload, item.options);
		if (!valid.ok) return null;
		try {
			return encodeQr(valid.canonical, item.options);
		} catch {
			return null;
		}
	}, [item]);
	if (isPending || user && cloud.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-96 animate-pulse rounded-xl bg-muted" });
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium",
				children: "Code not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "It may have been deleted, or it only existed on another device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/library",
					children: "Back to library"
				})
			})
		]
	});
	const record = item;
	const label = name ?? record.name;
	async function download(format) {
		if (!encoded) return;
		const filename = downloadFilename(record.payloadType, format === "jpeg" ? "jpg" : format);
		if (format === "svg") triggerDownload(svgToBlob(renderSvgString(encoded, record.options)), filename);
		else triggerDownload(await renderRasterBlob(encoded, record.options, format), filename);
		toast.success(`Downloaded ${filename}`);
	}
	async function onRename() {
		const next = label.trim();
		if (!next) return;
		if (user) {
			await saveCode({ data: {
				id: record.id,
				name: next,
				payload: record.payload,
				options: record.options,
				thumbnailSvg: record.thumbnailSvg
			} });
			await queryClient.invalidateQueries({ queryKey: ["code", id] });
			await queryClient.invalidateQueries({ queryKey: ["codes"] });
		} else upsertGuestCode({
			...record,
			name: next,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
		toast.success("Renamed");
	}
	async function onDelete() {
		if (!window.confirm(`Delete “${record.name}”?`)) return;
		if (user) {
			await deleteCode({ data: id });
			await queryClient.invalidateQueries({ queryKey: ["codes"] });
		} else deleteGuestCode(id);
		toast.success("Deleted");
		navigate({ to: "/library" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,360px)_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrPreview, {
			encoded,
			options: record.options,
			payloadType: record.payloadType,
			isStale: false,
			hint: null
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: TYPE_META[record.payloadType].short
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: "Static"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "code-name",
					children: "Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "code-name",
						value: label,
						onChange: (e) => setName(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => void onRename(),
						children: "Save name"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted-foreground tabular-nums",
				children: ["Updated ", new Date(record.updatedAt).toLocaleString()]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						disabled: !encoded,
						onClick: () => void download("png"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download PNG"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: !encoded,
						onClick: () => void download("svg"),
						children: "SVG"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: !encoded,
						onClick: () => void download("jpeg"),
						children: "JPEG"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/create",
							search: { type: record.payloadType },
							children: "Duplicate in workspace"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 rounded-xl border border-destructive/30 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-destructive",
						children: "Delete this code"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Removed from the default list. Guest copies cannot be restored."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "destructive",
						className: "mt-3",
						onClick: () => void onDelete(),
						children: "Delete"
					})
				]
			})
		] })]
	});
}
function DetailPage() {
	const { id } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeDetail, { id }) });
}
//#endregion
export { DetailPage as component };
