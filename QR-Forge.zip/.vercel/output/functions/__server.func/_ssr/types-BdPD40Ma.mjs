//#region node_modules/.nitro/vite/services/ssr/assets/types-BdPD40Ma.js
var PAYLOAD_TYPES = [
	"url",
	"text",
	"wifi",
	"vcard",
	"email",
	"sms",
	"tel",
	"geo"
];
var DEFAULT_OPTIONS = {
	fg: "#0F172A",
	bg: "#FFFFFF",
	ecc: "M",
	quietZoneModules: 4,
	modulePx: 8,
	caption: "",
	logoDataUrl: null,
	logoScale: .18
};
var MODULE_SCALES = [
	8,
	16,
	32
];
//#endregion
export { MODULE_SCALES as n, PAYLOAD_TYPES as r, DEFAULT_OPTIONS as t };
