import { i as encodeQr } from "./encode-D9rQXfc1.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as ScanLine, d as MessageSquare, h as Link2, i as Type, m as Mail, n as Wifi, o as ShieldCheck, p as MapPin, u as Phone, x as Contact, y as Download } from "../_libs/lucide-react.mjs";
import { r as SiteShell, t as Button } from "./site-shell-BAvZ8sYl.mjs";
import { i as svgForHtml, r as renderSvgString } from "./render-NdkZar8r.mjs";
import { t as Badge } from "./badge-CqJcIP66.mjs";
import { n as CardContent, t as Card } from "./card-B4Jr8XLJ.mjs";
import { t as DEFAULT_OPTIONS } from "./types-BdPD40Ma.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BhEH3Y3A.js
var import_jsx_runtime = require_jsx_runtime();
var sampleSvg = svgForHtml(renderSvgString(encodeQr("https://example.com/", {
	...DEFAULT_OPTIONS,
	modulePx: 8
}), {
	...DEFAULT_OPTIONS,
	caption: ""
}));
var PAYLOADS = [
	{
		type: "url",
		label: "Website",
		blurb: "http(s) only — no javascript: tricks.",
		icon: Link2
	},
	{
		type: "text",
		label: "Text",
		blurb: "Notes, codes, or a short message.",
		icon: Type
	},
	{
		type: "wifi",
		label: "Wi-Fi",
		blurb: "SSID, security, password. Escaped correctly.",
		icon: Wifi
	},
	{
		type: "vcard",
		label: "Contact",
		blurb: "vCard 3.0 with name, phone, email.",
		icon: Contact
	},
	{
		type: "email",
		label: "Email",
		blurb: "mailto with optional subject and body.",
		icon: Mail
	},
	{
		type: "sms",
		label: "SMS",
		blurb: "Number plus a draft message.",
		icon: MessageSquare
	},
	{
		type: "tel",
		label: "Phone",
		blurb: "One tap to call.",
		icon: Phone
	},
	{
		type: "geo",
		label: "Location",
		blurb: "Latitude and longitude.",
		icon: MapPin
	}
];
var FAQS = [
	{
		q: "Static vs dynamic — what’s the difference?",
		a: "A static code locks the content inside the image. Once printed, the destination cannot change. Dynamic codes (coming in Pro) encode a QRForge redirect so you can edit the URL after print."
	},
	{
		q: "Do you store my URL?",
		a: "Guest generation never leaves this browser. Saved library items are stored so you can reprint them. We never log payload contents."
	},
	{
		q: "Can I put a logo in the middle?",
		a: "Yes. PNG, SVG, or JPEG, auto-scaled, refused at error-correction L, and padded so finder patterns stay clear."
	},
	{
		q: "Can I use this commercially?",
		a: "Yes. Static downloads on the free plan have no watermark. Keep the quiet zone and test-scan before a bulk print run."
	}
];
function LandingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-20 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid items-center gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(280px,400px)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.2em] text-primary uppercase",
						children: "QR workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-5xl font-medium leading-[1.05] tracking-tight text-foreground sm:text-6xl",
						children: "Create scannable QR codes in the browser."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground",
						children: "No account required for static downloads. Preview is the file — sharp modules, a real quiet zone, and no watermark."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/create",
								search: { type: "url" },
								children: "Create a QR code"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/scan",
								children: "Scan a code"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-8 grid gap-2 text-sm text-muted-foreground sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-primary" }), " Guest-first, on-device encode"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 text-primary" }), " PNG, SVG, JPEG"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, { className: "size-4 text-primary" }), " Decode from photo or camera"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-4 text-primary" }), " Wi-Fi, vCard, URL, and more"]
							})
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg border border-border bg-card p-4",
							dangerouslySetInnerHTML: { __html: sampleSvg },
							"aria-label": "Sample QR code for https://example.com/"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: "example.com"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Static · ECC M · quiet zone 4"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: "No watermark"
							})]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"aria-label": "Proof",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						{
							title: "Static now",
							body: "Dynamic codes ship with Pro."
						},
						{
							title: "PNG + SVG",
							body: "Same encoder as the live preview."
						},
						{
							title: "Wi-Fi & vCard",
							body: "Canonical payloads phones understand."
						},
						{
							title: "No watermark",
							body: "Free static downloads stay clean."
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-card p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: item.body
						})]
					}, item.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl font-medium tracking-tight",
				children: "How it works"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-6 grid gap-4 md:grid-cols-3",
				children: [
					{
						n: "01",
						t: "Type the payload",
						d: "URL, Wi-Fi, contact, or text. Invalid schemes are blocked before a matrix exists."
					},
					{
						n: "02",
						t: "Style for scan",
						d: "Colors, error correction, quiet zone, optional logo. Contrast under 3:1 cannot download."
					},
					{
						n: "03",
						t: "Download or save",
						d: "PNG, SVG, or JPEG named for the job. Sign in only if you want a library."
					}
				].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-primary",
							children: step.n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-xl font-medium",
							children: step.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: step.d
						})
					]
				}, step.n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Payload types"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/create",
					search: { type: "url" },
					className: "text-sm font-medium text-primary hover:underline",
					children: "Open workspace"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: PAYLOADS.map((p) => {
					const Icon = p.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/create",
						search: { type: p.type },
						className: "group rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-medium group-hover:text-primary",
								children: p.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: p.blurb
							})
						]
					}, p.type);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Free" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-3xl font-medium",
							children: "Available now"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "30 saved static codes / month" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "All payload types, logo, SVG" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Guest downloads unlimited on-device" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No watermark on static files" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/create",
								search: { type: "url" },
								children: "Start creating"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-dashed border-border bg-muted/40 p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: "Pro · coming"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-3xl font-medium",
							children: "After print, still editable"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Dynamic codes with a short redirect" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Scan counts and pause/resume" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Unlimited static library" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "API keys for CI jobs" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pricing",
								children: "See plans"
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl font-medium tracking-tight",
				children: "FAQ"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 divide-y divide-border rounded-xl border border-border bg-card",
				children: FAQS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer list-none font-medium marker:content-none",
						children: item.q
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: item.a
					})]
				}, item.q))
			})] })
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		type: "application/ld+json",
		dangerouslySetInnerHTML: { __html: JSON.stringify({
			"@context": "https://schema.org",
			"@type": "SoftwareApplication",
			name: "QRForge",
			applicationCategory: "DesignApplication",
			operatingSystem: "Web",
			description: "Create scannable QR codes in the browser without an account for static downloads.",
			offers: {
				"@type": "Offer",
				price: "0",
				priceCurrency: "USD"
			}
		}) }
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingPage, {})] });
}
//#endregion
export { Home as component };
