import { l as serializePayload, s as getSql } from "./payloads-BlugSDx7.mjs";
import { r as encodeOptionsError } from "./encode-D9rQXfc1.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-2xursSUW.mjs";
import { r as PAYLOAD_TYPES } from "./types-BdPD40Ma.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/codes-qN7stwo-.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asIso(value) {
	return value instanceof Date ? value.toISOString() : String(value);
}
function mapRow(row) {
	return {
		id: row.id,
		name: row.name,
		payloadType: row.payload_type,
		payload: JSON.parse(row.payload),
		options: JSON.parse(row.options_json),
		thumbnailSvg: row.thumbnail_svg,
		createdAt: asIso(row.created_at),
		updatedAt: asIso(row.updated_at)
	};
}
function assertSavable(input) {
	const name = input.name.trim().slice(0, 80);
	if (!name) throw new Error("Name is required");
	const serialized = serializePayload(input.payload);
	if (!serialized.ok) throw new Error(serialized.message);
	const optionError = encodeOptionsError(input.options);
	if (optionError) throw new Error(optionError);
	if (!PAYLOAD_TYPES.includes(input.payload.type)) throw new Error("Unknown payload type");
	return {
		name,
		canonical: serialized.canonical
	};
}
async function persistCode(userId, data, enforceQuota) {
	const { name } = assertSavable(data);
	const sql = await getSql();
	const id = data.id ?? crypto.randomUUID();
	const existing = await sql`
    select id from codes where id = ${id} and user_id = ${userId} limit 1
  `;
	if (!existing[0] && enforceQuota) {
		if (((await sql`
      select count(*)::int as n from codes
      where user_id = ${userId}
        and created_at > now() - interval '30 days'
        and deleted_at is null
    `)[0]?.n ?? 0) >= 30) throw new Error("Free plan allows 30 saved codes per month.");
	}
	const payloadJson = JSON.stringify(data.payload);
	const optionsJson = JSON.stringify(data.options);
	const thumb = data.thumbnailSvg ?? null;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	if (existing[0]) await sql`
      update codes
      set name = ${name},
          payload_type = ${data.payload.type},
          payload = ${payloadJson},
          options_json = ${optionsJson},
          thumbnail_svg = ${thumb},
          updated_at = ${now},
          deleted_at = null
      where id = ${id} and user_id = ${userId}
    `;
	else await sql`
      insert into codes (id, user_id, name, payload_type, payload, options_json, thumbnail_svg, created_at, updated_at)
      values (${id}, ${userId}, ${name}, ${data.payload.type}, ${payloadJson}, ${optionsJson}, ${thumb}, ${now}, ${now})
    `;
	const row = (await sql`
    select id, name, payload_type, payload, options_json, thumbnail_svg, created_at, updated_at
    from codes where id = ${id} and user_id = ${userId} limit 1
  `)[0];
	if (!row) throw new Error("Could not save code");
	return mapRow(row);
}
var listCodes_createServerFn_handler = createServerRpc({
	id: "09e48ffa99da9a3a4f80f8173b5b3b51252fac9d5f23ebb704b3a27319123e6b",
	name: "listCodes",
	filename: "src/lib/codes.ts"
}, (opts) => listCodes.__executeServer(opts));
var listCodes = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input ?? {}).handler(listCodes_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const q = data.q?.trim().toLowerCase() ?? "";
	const type = data.type && PAYLOAD_TYPES.includes(data.type) ? data.type : "";
	return (await sql`
      select id, name, payload_type, payload, options_json, thumbnail_svg, created_at, updated_at
      from codes
      where user_id = ${context.userId}
        and deleted_at is null
      order by updated_at desc
      limit 200
    `).map(mapRow).filter((row) => {
		if (type && row.payloadType !== type) return false;
		if (!q) return true;
		if (`${row.name} ${row.payloadType}`.toLowerCase().includes(q)) return true;
		if (row.payload.type === "url") return row.payload.url.toLowerCase().includes(q);
		return false;
	});
});
var getCode_createServerFn_handler = createServerRpc({
	id: "349ea65bf35e07dea401df3cd588054bfaaa5b8ec4a1b4c051efd9343bbde37c",
	name: "getCode",
	filename: "src/lib/codes.ts"
}, (opts) => getCode.__executeServer(opts));
var getCode = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => id).handler(getCode_createServerFn_handler, async ({ context, data: id }) => {
	const row = (await (await getSql())`
      select id, name, payload_type, payload, options_json, thumbnail_svg, created_at, updated_at
      from codes
      where id = ${id} and user_id = ${context.userId} and deleted_at is null
      limit 1
    `)[0];
	if (!row) throw new Error("Not found");
	return mapRow(row);
});
var saveCode_createServerFn_handler = createServerRpc({
	id: "8b48bd829f8fc32b32147a527aec2226b2f790e7072251019a385e474a3fd526",
	name: "saveCode",
	filename: "src/lib/codes.ts"
}, (opts) => saveCode.__executeServer(opts));
var saveCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveCode_createServerFn_handler, async ({ context, data }) => {
	return persistCode(context.userId, data, true);
});
var deleteCode_createServerFn_handler = createServerRpc({
	id: "195c5e3fb596721ac19f91cfc83687b40192ed62f017fbb53434a1ae69a011a5",
	name: "deleteCode",
	filename: "src/lib/codes.ts"
}, (opts) => deleteCode.__executeServer(opts));
var deleteCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deleteCode_createServerFn_handler, async ({ context, data: id }) => {
	await (await getSql())`
      update codes
      set deleted_at = now(), updated_at = now()
      where id = ${id} and user_id = ${context.userId} and deleted_at is null
    `;
	return { ok: true };
});
var mergeGuestCodes_createServerFn_handler = createServerRpc({
	id: "c3f7b68cd4c86ae86ac9301d50754c8622d3adb5a61b964fc0ec584c128d2f53",
	name: "mergeGuestCodes",
	filename: "src/lib/codes.ts"
}, (opts) => mergeGuestCodes.__executeServer(opts));
var mergeGuestCodes = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(mergeGuestCodes_createServerFn_handler, async ({ context, data }) => {
	let imported = 0;
	let skipped = 0;
	for (const item of data.items.slice(0, 20)) try {
		await persistCode(context.userId, {
			name: item.name,
			payload: item.payload,
			options: item.options,
			thumbnailSvg: item.thumbnailSvg ?? null
		}, true);
		imported += 1;
	} catch {
		skipped += 1;
	}
	return {
		imported,
		skipped
	};
});
var deleteAllMyCodes_createServerFn_handler = createServerRpc({
	id: "b2fe247f3ab137fd2b09a3c537e0b465d615836e8e9e92c166542103aeea2a66",
	name: "deleteAllMyCodes",
	filename: "src/lib/codes.ts"
}, (opts) => deleteAllMyCodes.__executeServer(opts));
var deleteAllMyCodes = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(deleteAllMyCodes_createServerFn_handler, async ({ context }) => {
	await (await getSql())`update codes set deleted_at = now(), updated_at = now() where user_id = ${context.userId} and deleted_at is null`;
	return { ok: true };
});
var exportMyCodes_createServerFn_handler = createServerRpc({
	id: "4575704da9297c580df0b73e2f3cdd3f542fe5a4e32a9120c935ff2890d98482",
	name: "exportMyCodes",
	filename: "src/lib/codes.ts"
}, (opts) => exportMyCodes.__executeServer(opts));
var exportMyCodes = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(exportMyCodes_createServerFn_handler, async ({ context }) => {
	const rows = await (await getSql())`
      select id, name, payload_type, payload, options_json, thumbnail_svg, created_at, updated_at
      from codes
      where user_id = ${context.userId} and deleted_at is null
      order by updated_at desc
    `;
	return {
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		codes: rows.map((row) => {
			const mapped = mapRow(row);
			return {
				id: mapped.id,
				name: mapped.name,
				payloadType: mapped.payloadType,
				payload: mapped.payload,
				options: mapped.options,
				createdAt: mapped.createdAt,
				updatedAt: mapped.updatedAt
			};
		})
	};
});
//#endregion
export { deleteAllMyCodes_createServerFn_handler, deleteCode_createServerFn_handler, exportMyCodes_createServerFn_handler, getCode_createServerFn_handler, listCodes_createServerFn_handler, mergeGuestCodes_createServerFn_handler, saveCode_createServerFn_handler };
