import { o as __toESM } from "../_runtime.mjs";
import { r as detectPayloadType, t as TYPE_META } from "./payloads-BlugSDx7.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ExternalLink, b as Copy, g as Flashlight, r as Upload, t as X, w as Camera } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as cn, r as SiteShell, t as Button } from "./site-shell-BAvZ8sYl.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Badge } from "./badge-CqJcIP66.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B4Jr8XLJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-CtkCsvCV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function decodeWithBarcodeDetector(bitmap) {
	const Detector = globalThis.BarcodeDetector;
	if (!Detector) return null;
	try {
		const codes = await new Detector({ formats: ["qr_code"] }).detect(bitmap);
		if (!codes.length) return [];
		return codes.map((c) => ({
			text: c.rawValue,
			format: c.format
		}));
	} catch {
		return null;
	}
}
async function decodeWithJsQr(imageData) {
	const { default: jsQR } = await import("../_libs/jsqr.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	const result = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: "attemptBoth" });
	return result?.data ? [{
		text: result.data,
		format: "qr_code"
	}] : [];
}
async function decodeImageFile(file) {
	if (file.size > 10485760) throw new Error("Image must be 10 MB or smaller.");
	if (file.type && ![
		"image/jpeg",
		"image/png",
		"image/webp",
		"image/gif"
	].includes(file.type)) throw new Error("Use JPEG, PNG, WebP, or GIF.");
	const bitmap = await createImageBitmap(file);
	try {
		const detected = await decodeWithBarcodeDetector(bitmap);
		if (detected && detected.length) return detected;
		const canvas = document.createElement("canvas");
		canvas.width = bitmap.width;
		canvas.height = bitmap.height;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas unavailable");
		ctx.drawImage(bitmap, 0, 0);
		const fallback = await decodeWithJsQr(ctx.getImageData(0, 0, canvas.width, canvas.height));
		if (fallback.length) return fallback;
		return detected ?? [];
	} finally {
		bitmap.close();
	}
}
async function decodeVideoFrame(video) {
	if (!video.videoWidth) return [];
	const canvas = document.createElement("canvas");
	canvas.width = video.videoWidth;
	canvas.height = video.videoHeight;
	const ctx = canvas.getContext("2d");
	if (!ctx) return [];
	ctx.drawImage(video, 0, 0);
	try {
		const bitmap = await createImageBitmap(canvas);
		try {
			const detected = await decodeWithBarcodeDetector(bitmap);
			if (detected && detected.length) return detected;
		} finally {
			bitmap.close();
		}
	} catch {}
	return decodeWithJsQr(ctx.getImageData(0, 0, canvas.width, canvas.height));
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-ink/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border border-border bg-card p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute right-4 top-4 rounded-sm opacity-70 transition-opacity hover:opacity-100",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 text-left", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl font-medium", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function hostOf(url) {
	try {
		const u = new URL(url);
		if (u.protocol !== "http:" && u.protocol !== "https:") return null;
		return u.host;
	} catch {
		return null;
	}
}
function ScanWorkspace() {
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const timerRef = (0, import_react.useRef)(null);
	const [cameraOn, setCameraOn] = (0, import_react.useState)(false);
	const [cameraError, setCameraError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [hits, setHits] = (0, import_react.useState)([]);
	const [picked, setPicked] = (0, import_react.useState)(0);
	const [openSafe, setOpenSafe] = (0, import_react.useState)(false);
	const [torch, setTorch] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		return () => stopCamera();
	}, []);
	function stopCamera() {
		if (timerRef.current) window.clearInterval(timerRef.current);
		timerRef.current = null;
		streamRef.current?.getTracks().forEach((t) => t.stop());
		streamRef.current = null;
		setCameraOn(false);
		setTorch(false);
	}
	async function startCamera() {
		setCameraError(null);
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				video: { facingMode: { ideal: "environment" } },
				audio: false
			});
			streamRef.current = stream;
			const video = videoRef.current;
			if (video) {
				video.srcObject = stream;
				await video.play();
			}
			setCameraOn(true);
			timerRef.current = window.setInterval(() => {
				tick();
			}, 280);
		} catch {
			setCameraError("Camera permission was denied. Upload a photo instead.");
		}
	}
	async function tick() {
		const video = videoRef.current;
		if (!video || video.readyState < 2) return;
		try {
			const found = await decodeVideoFrame(video);
			if (found.length) {
				setHits(found);
				setPicked(0);
				stopCamera();
			}
		} catch {}
	}
	async function toggleTorch() {
		const track = streamRef.current?.getVideoTracks()[0];
		if (!track) return;
		try {
			await track.applyConstraints({ advanced: [{ torch: !torch }] });
			setTorch(!torch);
		} catch {
			toast.message("Torch is not available on this camera.");
		}
	}
	async function onFile(file) {
		if (!file) return;
		setBusy(true);
		setHits([]);
		try {
			const found = await decodeImageFile(file);
			setHits(found);
			setPicked(0);
			if (!found.length) toast.error("No QR code found. Try a tighter crop, more light, or less blur.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not decode that image");
		} finally {
			setBusy(false);
		}
	}
	const current = hits[picked];
	const type = current ? detectPayloadType(current.text) : null;
	const urlHost = current ? hostOf(current.text) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-primary uppercase",
					children: "Decoder"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl font-medium tracking-tight",
					children: "Scan a QR code"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-muted-foreground",
					children: "Decode happens in this browser. Images are not uploaded. Links never open until you confirm the domain."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							onClick: () => cameraOn ? stopCamera() : void startCamera(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), cameraOn ? "Stop camera" : "Use camera"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/jpeg,image/png,image/webp,image/gif",
							className: "sr-only",
							onChange: (e) => {
								onFile(e.target.files?.[0]);
								e.target.value = "";
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), busy ? "Reading…" : "Upload image"] })
							})
						})] }),
						cameraOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "secondary",
							onClick: () => void toggleTorch(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flashlight, {}), torch ? "Torch off" : "Torch"]
						}) : null
					]
				}),
				cameraError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-destructive",
					role: "alert",
					children: cameraError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 overflow-hidden rounded-xl border border-border bg-ink",
					onDragOver: (e) => e.preventDefault(),
					onDrop: (e) => {
						e.preventDefault();
						onFile(e.dataTransfer.files[0]);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						className: cameraOn ? "aspect-[4/3] w-full object-cover" : "hidden",
						playsInline: true,
						muted: true
					}), !cameraOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex aspect-[4/3] items-center justify-center px-6 text-center text-sm text-primary-foreground/80",
						children: "Drop a JPEG, PNG, WebP, or GIF here — or start the camera."
					}) : null]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Result" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "grid gap-4",
				children: !current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Nothing decoded yet. Point the camera at a code or upload a photo of a poster, screen, or print."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					hits.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: hits.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: i === picked ? "default" : "outline",
							onClick: () => setPicked(i),
							children: ["Code ", i + 1]
						}, `${h.text}-${i}`))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [type ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: TYPE_META[type].short }) : null, urlHost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: urlHost
						}) : null]
					}),
					urlHost ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"This code opens ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: urlHost
							}),
							". Confirm before leaving QRForge."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "max-h-56 overflow-auto rounded-md bg-muted p-3 font-mono text-xs whitespace-pre-wrap break-all",
						children: current.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								onClick: async () => {
									await navigator.clipboard.writeText(current.text);
									toast.success("Copied payload");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copy"]
							}),
							urlHost ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								onClick: () => setOpenSafe(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {}), "Safe Open"]
							}) : null,
							type ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/create",
									search: { type },
									children: "Make a new code"
								})
							}) : null
						]
					})
				] })
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: openSafe,
				onOpenChange: setOpenSafe,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Open this link?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						"You are leaving QRForge for ",
						urlHost,
						". We do not verify the destination."
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "break-all font-mono text-xs text-muted-foreground",
						children: current?.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setOpenSafe(false),
							children: "Stay here"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							onClick: () => {
								if (current) window.open(current.text, "_blank", "noopener,noreferrer");
								setOpenSafe(false);
							},
							children: ["Open ", urlHost]
						})]
					})
				] })
			})
		]
	});
}
function ScanPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanWorkspace, {}) });
}
//#endregion
export { ScanPage as component };
