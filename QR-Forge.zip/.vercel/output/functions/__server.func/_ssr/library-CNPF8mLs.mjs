import { o as __toESM } from "../_runtime.mjs";
import { t as TYPE_META } from "./payloads-BlugSDx7.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { s as Search, v as Ellipsis } from "../_libs/lucide-react.mjs";
import { a as useCurrentUserState, i as cn, r as SiteShell, t as Button } from "./site-shell-BAvZ8sYl.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as listCodes, n as deleteCode, o as mergeGuestCodes } from "./codes-WA1A9r9f.mjs";
import { i as svgForHtml } from "./render-NdkZar8r.mjs";
import { t as Badge } from "./badge-CqJcIP66.mjs";
import { i as guestHasSensitive, n as deleteGuestCode, o as useGuestCodes, t as clearGuestCodes } from "./guest-store-BsRbmkuB.mjs";
import { t as Input } from "./input-BdJvMhDZ.mjs";
import { r as PAYLOAD_TYPES } from "./types-BdPD40Ma.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DMx4l5yx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-CNPF8mLs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset,
		className: cn("z-50 min-w-40 overflow-hidden rounded-lg border border-border bg-card p-1 text-foreground shadow-md", className),
		...props
	}) });
}
function DropdownMenuItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("relative flex cursor-pointer select-none items-center rounded-sm px-2 py-2 text-sm outline-none data-[highlighted]:bg-muted", className),
		...props
	});
}
function matches(item, q, type) {
	if (type && type !== "all" && item.payloadType !== type) return false;
	if (!q) return true;
	if (`${item.name} ${item.payloadType}`.toLowerCase().includes(q)) return true;
	if (item.payload.type === "url") return item.payload.url.toLowerCase().includes(q);
	return false;
}
function CodeCard({ item, source, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col overflow-hidden rounded-xl border border-border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/library/$id",
			params: { id: item.id },
			className: "block aspect-square bg-muted p-4",
			children: item.thumbnailSvg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full w-full [&_svg]:h-full [&_svg]:w-full",
				dangerouslySetInnerHTML: { __html: svgForHtml(item.thumbnailSvg) }
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-full place-items-center text-sm text-muted-foreground",
				children: "No preview"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-2 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/library/$id",
						params: { id: item.id },
						className: "block truncate font-medium hover:underline",
						children: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex flex-wrap gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: TYPE_META[item.payloadType].short
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: "Static"
							}),
							source === "device" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: "This device"
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted-foreground tabular-nums",
						children: new Date(item.updatedAt).toLocaleString()
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": `Actions for ${item.name}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/library/$id",
						params: { id: item.id },
						children: "Open"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
					onClick: () => {
						if (window.confirm(`Delete “${item.name}”?`)) onDelete(item.id);
					},
					children: "Delete"
				})]
			})] })]
		})]
	});
}
function LibraryView() {
	const { user, isPending } = useCurrentUserState();
	const guest = useGuestCodes();
	const queryClient = useQueryClient();
	const [q, setQ] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("all");
	const [merging, setMerging] = (0, import_react.useState)(false);
	const cloud = useQuery({
		queryKey: [
			"codes",
			user?.id,
			q,
			type
		],
		queryFn: () => listCodes({ data: {
			q: q || void 0,
			type: type === "all" ? void 0 : type
		} }),
		enabled: Boolean(user)
	});
	const filteredGuest = (0, import_react.useMemo)(() => guest.filter((item) => matches(item, q.toLowerCase(), type)), [
		guest,
		q,
		type
	]);
	async function onDelete(id) {
		if (user) try {
			await deleteCode({ data: id });
			await queryClient.invalidateQueries({ queryKey: ["codes"] });
			toast.success("Deleted");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete");
		}
		else {
			deleteGuestCode(id);
			toast.success("Deleted from this device");
		}
	}
	async function onMerge() {
		if (!user || !guest.length) return;
		setMerging(true);
		try {
			const result = await mergeGuestCodes({ data: { items: guest.map((item) => ({
				name: item.name,
				payload: item.payload,
				options: item.options,
				thumbnailSvg: item.thumbnailSvg
			})) } });
			clearGuestCodes();
			await queryClient.invalidateQueries({ queryKey: ["codes"] });
			toast.success(`Imported ${result.imported} code${result.imported === 1 ? "" : "s"}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not import");
		} finally {
			setMerging(false);
		}
	}
	const emptyCloud = user && !cloud.isLoading && !cloud.data?.length;
	const emptyGuest = !user && filteredGuest.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-primary uppercase",
					children: "Library"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-medium tracking-tight",
					children: "Your codes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl text-muted-foreground",
					children: user ? "Saved to your account. Re-download any format from the original payload." : "Last 20 codes stay on this device. Sign in to keep them across browsers."
				})
			]
		}),
		user && guest.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 rounded-xl border border-border bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						guest.length,
						" code",
						guest.length === 1 ? "" : "s",
						" on this device"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: guestHasSensitive(guest) ? "This list includes Wi-Fi or contact cards. Import only if you trust this browser." : "Import them into your account, or leave them local."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => void onMerge(),
						disabled: merging,
						children: merging ? "Importing…" : "Import to library"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => clearGuestCodes(),
						children: "Discard local copies"
					})]
				})
			]
		}) : null,
		!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm",
			children: [
				"Guest history never left this device.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					search: { next: "/library" },
					className: "font-medium text-primary hover:underline",
					children: "Sign in to sync"
				}),
				"."
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-col gap-3 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search by name or URL host",
					className: "pl-9",
					"aria-label": "Search codes"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: type,
				onValueChange: setType,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "sm:w-44",
					"aria-label": "Filter by type",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "all",
					children: "All types"
				}), PAYLOAD_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: t,
					children: TYPE_META[t].short
				}, t))] })]
			})]
		}),
		isPending || user && cloud.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-square animate-pulse rounded-xl bg-muted" }, i))
		}) : emptyCloud || emptyGuest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-dashed border-border px-6 py-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-medium",
					children: "Create your first code"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The workspace encodes in the browser. Download PNG in seconds."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/create",
						search: { type: "url" },
						children: "Create a QR code"
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: user ? (cloud.data ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeCard, {
				item,
				source: "cloud",
				onDelete: (id) => void onDelete(id)
			}, item.id)) : filteredGuest.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeCard, {
				item,
				source: "device",
				onDelete: (id) => void onDelete(id)
			}, item.id))
		})
	] });
}
function LibraryPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryView, {}) });
}
//#endregion
export { LibraryPage as component };
