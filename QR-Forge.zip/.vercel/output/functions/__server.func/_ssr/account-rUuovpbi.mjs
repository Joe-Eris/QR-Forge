import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useCurrentUserState, n as RedirectToSignIn, r as SiteShell, t as Button } from "./site-shell-BAvZ8sYl.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as exportMyCodes, t as deleteAllMyCodes } from "./codes-WA1A9r9f.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B4Jr8XLJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-rUuovpbi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountPage() {
	const { user, isPending } = useCurrentUserState();
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse rounded-xl bg-muted" }) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function onExport() {
		setBusy(true);
		try {
			const data = await exportMyCodes();
			const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "qrforge-export.json";
			a.click();
			URL.revokeObjectURL(url);
			toast.success("Export downloaded");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Export failed");
		} finally {
			setBusy(false);
		}
	}
	async function onDeleteLibrary() {
		if (!window.confirm("Soft-delete every saved code in your library?")) return;
		setBusy(true);
		try {
			await deleteAllMyCodes();
			toast.success("Library cleared");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.18em] text-primary uppercase",
			children: "Account"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl font-medium tracking-tight",
			children: "Your profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-4 max-w-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Identity" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Name · "
				}), user.displayName ?? "—"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Email · "
				}), user.primaryEmail ?? "—"] })]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Data" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					disabled: busy,
					onClick: () => void onExport(),
					children: "Export library JSON"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "destructive",
					disabled: busy,
					onClick: () => void onDeleteLibrary(),
					children: "Delete saved codes"
				})]
			})] })]
		})
	] });
}
//#endregion
export { AccountPage as component };
