import { o as __toESM } from "../_runtime.mjs";
import { i as emptyPayload, l as serializePayload, n as defaultName, t as TYPE_META } from "./payloads-BlugSDx7.mjs";
import { a as maxLogoScale, i as encodeQr, n as contrastGate, o as versionHint, t as canGenerate } from "./encode-D9rQXfc1.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Copy, l as Save, y as Download } from "../_libs/lucide-react.mjs";
import { a as useCurrentUserState, i as cn, r as SiteShell, t as Button } from "./site-shell-BAvZ8sYl.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Tooltip, i as Route$8, o as TooltipContent, s as TooltipTrigger } from "./router-JkJchIMp.mjs";
import { s as saveCode } from "./codes-WA1A9r9f.mjs";
import { a as svgToBlob, n as renderRasterBlob, o as triggerDownload, r as renderSvgString, t as rasterizeLogo } from "./render-NdkZar8r.mjs";
import { n as downloadFilename, t as QrPreview } from "./qr-preview-BUJtRhpV.mjs";
import { a as upsertGuestCode } from "./guest-store-BsRbmkuB.mjs";
import { t as Input } from "./input-BdJvMhDZ.mjs";
import { t as Label } from "./label-bnuyJOOq.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B4Jr8XLJ.mjs";
import { n as MODULE_SCALES, r as PAYLOAD_TYPES, t as DEFAULT_OPTIONS } from "./types-BdPD40Ma.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DMx4l5yx.mjs";
import { n as Root2, r as Trigger, t as List } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/create-BjOoJyR3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Field({ id, label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: id,
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
function PayloadForm({ payload, onChange, errorField }) {
	const set = (patch) => onChange({
		...payload,
		...patch
	});
	switch (payload.type) {
		case "url": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			id: "url",
			label: "Website",
			hint: "http and https only. javascript: and data: are blocked.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "url",
				type: "url",
				inputMode: "url",
				autoComplete: "url",
				placeholder: TYPE_META.url.example,
				value: payload.url,
				"aria-invalid": errorField === "url",
				onChange: (e) => set({
					type: "url",
					url: e.target.value
				})
			})
		});
		case "text": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			id: "text",
			label: "Text",
			hint: `${payload.text.length}/1,200`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				id: "text",
				placeholder: TYPE_META.text.example,
				value: payload.text,
				maxLength: 1200,
				"aria-invalid": errorField === "text",
				onChange: (e) => set({
					type: "text",
					text: e.target.value
				})
			})
		});
		case "wifi": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "ssid",
					label: "Network name (SSID)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ssid",
						value: payload.ssid,
						maxLength: 32,
						placeholder: "Cafe-Guest",
						"aria-invalid": errorField === "ssid",
						onChange: (e) => set({
							type: "wifi",
							ssid: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "security",
					label: "Security",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: payload.security,
						onValueChange: (v) => set({
							type: "wifi",
							security: v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							id: "security",
							"aria-label": "Wi-Fi security",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "WPA2",
								children: "WPA2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "WPA3",
								children: "WPA3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "WPA",
								children: "WPA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "WEP",
								children: "WEP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "NONE",
								children: "Open (no password)"
							})
						] })]
					})
				}),
				payload.security !== "NONE" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "password",
					label: "Password",
					hint: "Never shown in the page title or social preview.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "password",
						type: "password",
						autoComplete: "off",
						value: payload.password,
						maxLength: 63,
						"aria-invalid": errorField === "password",
						onChange: (e) => set({
							type: "wifi",
							password: e.target.value
						})
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-4 accent-primary",
						checked: payload.hidden,
						onChange: (e) => set({
							type: "wifi",
							hidden: e.target.checked
						})
					}), "Hidden network"]
				})
			]
		});
		case "vcard": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "fn",
					label: "Full name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "fn",
						value: payload.fn,
						"aria-invalid": errorField === "fn",
						onChange: (e) => set({
							type: "vcard",
							fn: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "org",
					label: "Organization",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "org",
						value: payload.org,
						onChange: (e) => set({
							type: "vcard",
							org: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "vtel",
					label: "Phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "vtel",
						value: payload.tel,
						onChange: (e) => set({
							type: "vcard",
							tel: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "vemail",
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "vemail",
						type: "email",
						value: payload.email,
						onChange: (e) => set({
							type: "vcard",
							email: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "vurl",
					label: "Website",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "vurl",
						value: payload.url,
						onChange: (e) => set({
							type: "vcard",
							url: e.target.value
						})
					})
				})
			]
		});
		case "email": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "address",
					label: "Address",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "address",
						type: "email",
						value: payload.address,
						"aria-invalid": errorField === "address",
						onChange: (e) => set({
							type: "email",
							address: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "subject",
					label: "Subject",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "subject",
						value: payload.subject,
						onChange: (e) => set({
							type: "email",
							subject: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "body",
					label: "Body",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "body",
						value: payload.body,
						onChange: (e) => set({
							type: "email",
							body: e.target.value
						})
					})
				})
			]
		});
		case "sms": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "sms-number",
				label: "Number",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "sms-number",
					value: payload.number,
					"aria-invalid": errorField === "number",
					onChange: (e) => set({
						type: "sms",
						number: e.target.value
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "sms-body",
				label: "Message",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "sms-body",
					value: payload.body,
					onChange: (e) => set({
						type: "sms",
						body: e.target.value
					})
				})
			})]
		});
		case "tel": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			id: "tel",
			label: "Phone number",
			hint: "E.164 suggested, not required.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "tel",
				type: "tel",
				placeholder: "+15551234567",
				value: payload.number,
				"aria-invalid": errorField === "number",
				onChange: (e) => set({
					type: "tel",
					number: e.target.value
				})
			})
		});
		case "geo": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "lat",
				label: "Latitude",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "lat",
					inputMode: "decimal",
					value: payload.lat,
					"aria-invalid": errorField === "lat",
					onChange: (e) => set({
						type: "geo",
						lat: e.target.value
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "lng",
				label: "Longitude",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "lng",
					inputMode: "decimal",
					value: payload.lng,
					"aria-invalid": errorField === "lng",
					onChange: (e) => set({
						type: "geo",
						lng: e.target.value
					})
				})
			})]
		});
	}
}
var PRESETS = [
	{
		name: "Monochrome",
		patch: {
			fg: "#0F172A",
			bg: "#FFFFFF"
		}
	},
	{
		name: "High contrast",
		patch: {
			fg: "#000000",
			bg: "#FFFFFF"
		}
	},
	{
		name: "Brand",
		patch: {
			fg: "#0369A1",
			bg: "#F8FAFC"
		}
	},
	{
		name: "Inverse",
		patch: {
			fg: "#F8FAFC",
			bg: "#0F172A"
		}
	}
];
function DesignPanel({ options, onChange }) {
	const gate = contrastGate(options.fg, options.bg);
	const logoMax = maxLogoScale(options.ecc);
	async function onLogo(file) {
		if (!file) return;
		try {
			const dataUrl = await rasterizeLogo(file);
			const ecc = options.ecc === "L" ? "H" : options.ecc;
			onChange({
				...options,
				logoDataUrl: dataUrl,
				ecc,
				logoScale: Math.min(options.logoScale, maxLogoScale(ecc) || .18)
			});
			if (options.ecc === "L") toast.message("Error correction raised to H for the logo.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not use that logo");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: "Presets"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					onClick: () => onChange({
						...options,
						...p.patch
					}),
					children: p.name
				}, p.name))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "fg",
						children: "Modules"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": "Module color",
							type: "color",
							className: "size-11 shrink-0 cursor-pointer rounded-md border border-input bg-card",
							value: options.fg,
							onChange: (e) => onChange({
								...options,
								fg: e.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "fg",
							value: options.fg,
							onChange: (e) => onChange({
								...options,
								fg: e.target.value
							}),
							className: "font-mono uppercase"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "bg",
						children: "Background"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": "Background color",
							type: "color",
							className: "size-11 shrink-0 cursor-pointer rounded-md border border-input bg-card",
							value: options.bg,
							onChange: (e) => onChange({
								...options,
								bg: e.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "bg",
							value: options.bg,
							onChange: (e) => onChange({
								...options,
								bg: e.target.value
							}),
							className: "font-mono uppercase"
						})]
					})]
				})]
			}),
			gate.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: gate.status === "block" ? "rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive" : "rounded-md bg-muted px-3 py-2 text-sm text-foreground",
				role: gate.status === "block" ? "alert" : "status",
				children: gate.message
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground tabular-nums",
				children: [
					"Contrast ",
					gate.ratio.toFixed(2),
					":1"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Error correction" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: options.ecc,
						onValueChange: (v) => {
							const ecc = v;
							if (options.logoDataUrl && ecc === "L") return;
							onChange({
								...options,
								ecc
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							"aria-label": "Error correction",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "L",
								children: "L · 7%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "M",
								children: "M · 15%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Q",
								children: "Q · 25%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "H",
								children: "H · 30%"
							})
						] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Module size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: String(options.modulePx),
						onValueChange: (v) => onChange({
							...options,
							modulePx: Number(v)
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							"aria-label": "Module size",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: MODULE_SCALES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: String(n),
							children: [n, " px / module"]
						}, n)) })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "quiet",
						children: "Quiet zone (modules)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "quiet",
						type: "number",
						min: 4,
						max: 16,
						value: options.quietZoneModules,
						onChange: (e) => onChange({
							...options,
							quietZoneModules: Math.max(4, Number(e.target.value) || 4)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Minimum 4. Never decrease below that."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "caption",
					children: "Caption (optional, not in the QR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "caption",
					maxLength: 48,
					value: options.caption,
					placeholder: "Scan for menu",
					onChange: (e) => onChange({
						...options,
						caption: e.target.value.slice(0, 48)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "logo",
						children: "Center logo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "logo",
						type: "file",
						accept: "image/png,image/jpeg,image/svg+xml,image/webp",
						onChange: (e) => void onLogo(e.target.files?.[0])
					}),
					options.logoDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [
								"Logo on · max ",
								Math.round(logoMax * 100),
								"% width at ",
								options.ecc
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							onClick: () => onChange({
								...options,
								logoDataUrl: null
							}),
							children: "Remove"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "PNG, SVG, JPEG. Refused at ECC L. Auto-padded so finders stay clear."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "secondary",
				onClick: () => onChange({ ...DEFAULT_OPTIONS }),
				children: "Reset to defaults"
			})
		]
	});
}
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("inline-flex h-11 items-center justify-start gap-1 rounded-lg bg-muted p-1 text-muted-foreground overflow-x-auto", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex h-9 items-center justify-center whitespace-nowrap rounded-md px-3 text-sm font-medium transition-colors data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-sm disabled:opacity-50", className),
		...props
	});
}
function CreateWorkspace({ initialType }) {
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [payload, setPayload] = (0, import_react.useState)(() => emptyPayload(initialType));
	const [options, setOptions] = (0, import_react.useState)(DEFAULT_OPTIONS);
	const [name, setName] = (0, import_react.useState)("Untitled");
	const [encoded, setEncoded] = (0, import_react.useState)(null);
	const [stale, setStale] = (0, import_react.useState)(false);
	const [downloads, setDownloads] = (0, import_react.useState)(0);
	const debounce = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (payload.type !== initialType) {
			setPayload(emptyPayload(initialType));
			setEncoded(null);
		}
	}, [initialType]);
	const validation = (0, import_react.useMemo)(() => canGenerate(payload, options), [payload, options]);
	(0, import_react.useEffect)(() => {
		setStale(true);
		if (debounce.current) window.clearTimeout(debounce.current);
		debounce.current = window.setTimeout(() => {
			if (!validation.ok) {
				setEncoded(null);
				setStale(false);
				return;
			}
			try {
				setEncoded(encodeQr(validation.canonical, options));
			} catch {
				setEncoded(null);
			}
			setStale(false);
		}, 80);
		return () => {
			if (debounce.current) window.clearTimeout(debounce.current);
		};
	}, [validation, options]);
	const hint = encoded ? versionHint(encoded.version, options.ecc, Boolean(options.logoDataUrl)) : null;
	const blockedReason = !validation.ok ? validation.message : encoded ? null : "Waiting for a valid payload.";
	async function download(format) {
		if (!encoded || !validation.ok) return;
		const filename = downloadFilename(payload.type, format === "jpeg" ? "jpg" : format);
		if (format === "svg") triggerDownload(svgToBlob(renderSvgString(encoded, options)), filename);
		else {
			const blob = await renderRasterBlob(encoded, options, format);
			triggerDownload(blob, filename);
		}
		toast.success(`Downloaded ${filename}`);
		const next = downloads + 1;
		setDownloads(next);
		rememberGuest();
	}
	async function copyPng() {
		if (!encoded) return;
		try {
			const blob = await renderRasterBlob(encoded, options, "png");
			await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
			toast.success("Copied image");
		} catch {
			toast.error("Clipboard image is not available in this browser");
		}
	}
	function rememberGuest() {
		const id = crypto.randomUUID();
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const svg = encoded ? renderSvgString(encoded, options) : null;
		upsertGuestCode({
			id,
			name: name.trim() || defaultName(payload),
			payloadType: payload.type,
			payload,
			options,
			thumbnailSvg: svg,
			createdAt: now,
			updatedAt: now
		});
	}
	async function onSave() {
		if (!encoded || !validation.ok) return;
		const label = name.trim() || defaultName(payload);
		const thumb = renderSvgString(encoded, options);
		if (!user) {
			rememberGuest();
			toast.message("Saved on this device", {
				description: "Sign in to keep codes across browsers.",
				action: {
					label: "Sign in",
					onClick: () => navigate({
						to: "/login",
						search: { next: "/library" }
					})
				}
			});
			return;
		}
		try {
			await saveCode({ data: {
				name: label,
				payload,
				options,
				thumbnailSvg: thumb
			} });
			toast.success("Saved to library");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save");
		}
	}
	const ExportButtons = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					disabled: !encoded || !validation.ok,
					onClick: () => void download("png"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download PNG"]
				}) })
			}), blockedReason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: blockedReason }) : null] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				disabled: !encoded || !validation.ok,
				onClick: () => void download("svg"),
				children: "SVG"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				disabled: !encoded || !validation.ok,
				onClick: () => void download("jpeg"),
				children: "JPEG"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "secondary",
				disabled: !encoded,
				onClick: () => void copyPng(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copy"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "secondary",
				disabled: !encoded || !validation.ok,
				onClick: () => void onSave(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), isPending ? "Save" : user ? "Save to library" : "Save on this device"]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-24 lg:pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.18em] text-primary uppercase",
						children: "Workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl font-medium tracking-tight",
						children: "Create a static QR code"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-muted-foreground",
						children: "Static locks the content inside the image. No account is required to download. Preview is the file — no watermark."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: payload.type,
				onValueChange: (v) => {
					const type = v;
					setPayload(emptyPayload(type));
					navigate({
						to: "/create",
						search: { type },
						replace: true
					});
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
					className: "w-full md:w-auto",
					children: PAYLOAD_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: type,
						children: TYPE_META[type].short
					}, type))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(280px,340px)_minmax(0,1fr)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: TYPE_META[payload.type].label }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "name",
									children: "Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "name",
									value: name,
									onChange: (e) => setName(e.target.value),
									maxLength: 80
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayloadForm, {
								payload,
								onChange: setPayload,
								errorField: !validation.ok ? validation.field : void 0
							}),
							!validation.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-destructive",
								role: "alert",
								children: validation.message
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-mono text-xs text-muted-foreground",
								children: serializePayload(payload).ok ? serializePayload(payload).canonical : ""
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:sticky lg:top-24 h-fit",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrPreview, {
							encoded,
							options,
							payloadType: payload.type,
							isStale: stale,
							hint
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 hidden lg:block",
							children: ExportButtons
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Design" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesignPanel, {
						options,
						onChange: setOptions
					}) })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "mt-8 rounded-xl border border-border bg-card p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer font-medium",
					children: "Print checklist"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Outdoor poster: short URL, ECC M or H, printed width at least 4 cm." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Business card: high contrast, light logo, printed width at least 2 cm." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Matte finish. Do not crop the quiet zone." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Test-scan before a bulk print run." })
					]
				})]
			}),
			downloads >= 2 && !user && !isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-xl border border-border bg-card px-4 py-3 text-sm",
				children: [
					"Save codes across devices —",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						search: { next: "/library" },
						className: "font-medium text-primary underline-offset-4 hover:underline",
						children: "create a free account"
					}),
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 p-3 backdrop-blur lg:hidden",
				children: ExportButtons
			})
		]
	});
}
function CreatePage() {
	const { type } = Route$8.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateWorkspace, { initialType: type ?? "url" }) });
}
//#endregion
export { CreatePage as component };
