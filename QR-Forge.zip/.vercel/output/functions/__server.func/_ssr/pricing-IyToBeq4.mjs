import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as SiteShell, t as Button } from "./site-shell-BAvZ8sYl.mjs";
import { t as Badge } from "./badge-CqJcIP66.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-IyToBeq4.js
var import_jsx_runtime = require_jsx_runtime();
function PricingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.18em] text-primary uppercase",
			children: "Plans"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl font-medium tracking-tight",
			children: "Simple, honest pricing"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-xl text-muted-foreground",
			children: "Payments are not live yet. The Free plan is available now. Pro and Business are listed so you can plan a print run."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 grid gap-4 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Free" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-3xl font-medium",
							children: "$0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "30 saved static codes / month" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Logo, SVG, PNG, JPEG" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Guest downloads unlimited" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No watermark on static files" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "On-device scan decoder" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6 w-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/create",
								search: { type: "url" },
								children: "Create a QR code"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: "Pro · coming"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-3xl font-medium",
							children: "Soon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Unlimited static codes" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "50 active dynamic codes" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "13 months of scan analytics" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Limited public API" })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: "Business · coming"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-3xl font-medium",
							children: "Soon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "500+ dynamic codes" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "10 seats included" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "25 months analytics" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Full API" })
							]
						})
					]
				})
			]
		})
	] });
}
//#endregion
export { PricingPage as component };
