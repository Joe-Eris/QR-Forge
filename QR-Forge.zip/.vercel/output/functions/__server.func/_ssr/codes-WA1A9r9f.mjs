import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-2xursSUW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/codes-WA1A9r9f.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var listCodes = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input ?? {}).handler(createSsrRpc("09e48ffa99da9a3a4f80f8173b5b3b51252fac9d5f23ebb704b3a27319123e6b"));
var getCode = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("349ea65bf35e07dea401df3cd588054bfaaa5b8ec4a1b4c051efd9343bbde37c"));
var saveCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("8b48bd829f8fc32b32147a527aec2226b2f790e7072251019a385e474a3fd526"));
var deleteCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("195c5e3fb596721ac19f91cfc83687b40192ed62f017fbb53434a1ae69a011a5"));
var mergeGuestCodes = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("c3f7b68cd4c86ae86ac9301d50754c8622d3adb5a61b964fc0ec584c128d2f53"));
var deleteAllMyCodes = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("b2fe247f3ab137fd2b09a3c537e0b465d615836e8e9e92c166542103aeea2a66"));
var exportMyCodes = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4575704da9297c580df0b73e2f3cdd3f542fe5a4e32a9120c935ff2890d98482"));
//#endregion
export { listCodes as a, getCode as i, deleteCode as n, mergeGuestCodes as o, exportMyCodes as r, saveCode as s, deleteAllMyCodes as t };
