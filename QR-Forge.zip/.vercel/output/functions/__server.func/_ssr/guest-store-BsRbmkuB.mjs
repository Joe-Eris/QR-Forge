import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guest-store-BsRbmkuB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var GUEST_KEY = "qrforge.guest.v1";
var CAP = 20;
var VERSION = 1;
function empty() {
	return {
		version: VERSION,
		items: []
	};
}
function read() {
	if (typeof window === "undefined") return empty();
	try {
		const raw = window.localStorage.getItem(GUEST_KEY);
		if (!raw) return empty();
		const parsed = JSON.parse(raw);
		if (parsed.version !== VERSION || !Array.isArray(parsed.items)) return empty();
		return {
			version: VERSION,
			items: parsed.items.slice(0, CAP)
		};
	} catch {
		return empty();
	}
}
function write(store) {
	window.localStorage.setItem(GUEST_KEY, JSON.stringify({
		version: VERSION,
		items: store.items.slice(0, CAP)
	}));
	window.dispatchEvent(new Event("qrforge-guest"));
}
function listGuestCodes() {
	return read().items;
}
function getGuestCode(id) {
	return read().items.find((item) => item.id === id);
}
function upsertGuestCode(code) {
	const next = [code, ...read().items.filter((item) => item.id !== code.id)].slice(0, CAP);
	write({
		version: VERSION,
		items: next
	});
	return next;
}
function deleteGuestCode(id) {
	const next = read().items.filter((item) => item.id !== id);
	write({
		version: VERSION,
		items: next
	});
	return next;
}
function clearGuestCodes() {
	write(empty());
}
function guestHasSensitive(items = listGuestCodes()) {
	return items.some((item) => item.payloadType === "wifi" || item.payloadType === "vcard");
}
function useGuestCodes() {
	const [items, setItems] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const refresh = () => setItems(listGuestCodes());
		refresh();
		window.addEventListener("storage", refresh);
		window.addEventListener("qrforge-guest", refresh);
		return () => {
			window.removeEventListener("storage", refresh);
			window.removeEventListener("qrforge-guest", refresh);
		};
	}, []);
	return items;
}
//#endregion
export { upsertGuestCode as a, guestHasSensitive as i, deleteGuestCode as n, useGuestCodes as o, getGuestCode as r, clearGuestCodes as t };
