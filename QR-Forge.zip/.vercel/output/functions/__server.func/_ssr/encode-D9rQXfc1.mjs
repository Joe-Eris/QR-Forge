import { l as serializePayload } from "./payloads-BlugSDx7.mjs";
import { t as encode } from "../_libs/uqr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/encode-D9rQXfc1.js
function parseHex(hex) {
	const raw = hex.trim().replace("#", "");
	const full = raw.length === 3 ? raw.split("").map((c) => c + c).join("") : raw;
	if (!/^[0-9a-fA-F]{6}$/.test(full)) return null;
	return {
		r: parseInt(full.slice(0, 2), 16),
		g: parseInt(full.slice(2, 4), 16),
		b: parseInt(full.slice(4, 6), 16)
	};
}
function srgbToLin(channel) {
	const s = channel / 255;
	return s <= .04045 ? s / 12.92 : Math.pow((s + .055) / 1.055, 2.4);
}
function relativeLuminance(hex) {
	const rgb = parseHex(hex);
	if (!rgb) return null;
	return .2126 * srgbToLin(rgb.r) + .7152 * srgbToLin(rgb.g) + .0722 * srgbToLin(rgb.b);
}
function contrastRatio(fg, bg) {
	const a = relativeLuminance(fg);
	const b = relativeLuminance(bg);
	if (a == null || b == null) return null;
	const hi = Math.max(a, b);
	const lo = Math.min(a, b);
	return (hi + .05) / (lo + .05);
}
/** FR-4.1 warn < 4.5:1, FR-4.2 block < 3:1 */
function contrastGate(fg, bg) {
	const ratio = contrastRatio(fg, bg);
	if (ratio == null) return {
		ratio: 0,
		status: "block",
		message: "Enter valid hex colors for modules and background."
	};
	if (ratio < 3) return {
		ratio,
		status: "block",
		message: `Contrast ${ratio.toFixed(2)}:1 is too low. Scanners need at least 3:1 (aim for 7:1).`
	};
	if (ratio < 4.5) return {
		ratio,
		status: "warn",
		message: `Contrast ${ratio.toFixed(2)}:1 is weak. 4.5:1 is safer; 7:1 is recommended for print.`
	};
	return {
		ratio,
		status: "ok",
		message: null
	};
}
function encodeOptionsError(options) {
	const quiet = Math.round(options.quietZoneModules);
	if (!Number.isFinite(quiet) || quiet < 4) return "Quiet zone must be at least 4 modules.";
	if (options.logoDataUrl && options.ecc === "L") return "Logos need error correction M, Q, or H. L cannot recover covered modules.";
	const gate = contrastGate(options.fg, options.bg);
	if (gate.status === "block") return gate.message;
	return null;
}
function canGenerate(payload, options) {
	const optionError = encodeOptionsError(options);
	if (optionError) return {
		ok: false,
		message: optionError
	};
	return serializePayload(payload);
}
function encodeQr(canonical, options) {
	const quiet = Math.max(4, Math.round(options.quietZoneModules));
	const ecc = options.logoDataUrl && options.ecc === "L" ? "H" : options.ecc;
	const result = encode(canonical, {
		ecc,
		border: quiet,
		boostEcc: false
	});
	return {
		data: result.data,
		size: result.size,
		version: result.version,
		canonical
	};
}
function maxLogoScale(ecc) {
	if (ecc === "H") return .22;
	if (ecc === "Q") return .18;
	if (ecc === "M") return .12;
	return 0;
}
function versionHint(version, ecc, hasLogo) {
	if (hasLogo && ecc === "L") return "Raise error correction to H before adding a logo.";
	if (version >= 10) return `Version ${version} is dense. Shorten the payload or raise error correction for print.`;
	if (hasLogo && ecc === "M") return "Logo at ECC M is tight. H is safer for print runs.";
	return null;
}
//#endregion
export { maxLogoScale as a, encodeQr as i, contrastGate as n, versionHint as o, encodeOptionsError as r, canGenerate as t };
