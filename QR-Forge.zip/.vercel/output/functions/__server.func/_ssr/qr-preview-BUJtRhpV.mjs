import { o as __toESM } from "../_runtime.mjs";
import { t as TYPE_META } from "./payloads-BlugSDx7.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as cn } from "./site-shell-BAvZ8sYl.mjs";
import { i as svgForHtml, r as renderSvgString } from "./render-NdkZar8r.mjs";
import { t as Badge } from "./badge-CqJcIP66.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qr-preview-BUJtRhpV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function pad(n) {
	return String(n).padStart(2, "0");
}
function downloadFilename(type, ext, at = /* @__PURE__ */ new Date()) {
	return `qrforge-${type}-${at.getFullYear()}${pad(at.getMonth() + 1)}${pad(at.getDate())}-${pad(at.getHours())}${pad(at.getMinutes())}${pad(at.getSeconds())}.${ext}`;
}
function printSizeMm(pixelEdge, dpi = 300) {
	return pixelEdge / dpi * 25.4;
}
function QrPreview({ encoded, options, payloadType, isStale, hint }) {
	const svg = (0, import_react.useMemo)(() => {
		if (!encoded) return null;
		return svgForHtml(renderSvgString(encoded, options));
	}, [encoded, options]);
	const edge = encoded ? encoded.size * options.modulePx : 0;
	const mm = printSizeMm(edge);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("relative flex aspect-square w-full max-w-sm items-center justify-center rounded-xl border border-border bg-card p-5 transition-opacity", isStale && "opacity-60"),
				children: svg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-full",
					dangerouslySetInnerHTML: { __html: svg },
					"aria-live": "polite",
					"aria-label": `QR code for ${TYPE_META[payloadType].label}`
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-6 text-center text-sm text-muted-foreground",
					children: "Enter a payload to preview a live matrix. The file you download is this preview."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-center gap-2",
				children: [
					encoded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						className: "font-mono tabular-nums",
						children: [
							"Version ",
							encoded.version,
							" · ",
							encoded.size,
							"×",
							encoded.size
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						children: "No matrix"
					}),
					encoded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						className: "tabular-nums",
						children: [
							edge,
							" px · ~",
							mm.toFixed(0),
							" mm at 300 DPI"
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						children: "Static"
					})
				]
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-center text-xs text-muted-foreground",
				children: hint
			}) : null,
			options.modulePx * (encoded?.size ?? 0) < 128 && encoded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-center text-xs text-destructive",
				children: "Under 128 px is hard to scan from a phone. Increase module size."
			}) : null
		]
	});
}
//#endregion
export { downloadFilename as n, QrPreview as t };
