//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-l424HW0e.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/account",
			"/create",
			"/login",
			"/pricing",
			"/privacy",
			"/scan",
			"/terms",
			"/library/$id",
			"/library/",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-mA0h2MCo.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/client-D9440YHn.js",
			"/assets/site-shell-B9d_suMC.js",
			"/assets/createClientRpc-BgMLflIW.js",
			"/assets/lazyRouteComponent-CuVEOJXu.js",
			"/assets/redirect-BQPqGHuP.js",
			"/assets/dist-CKZR_nNm.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/login-DT6vjQcb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mA0h2MCo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BTzlScFk.js",
			"/assets/download-DgFt_HG3.js",
			"/assets/card-DCgkpyd6.js",
			"/assets/render-DDRfgRkN.js",
			"/assets/types-CpXr79mB.js",
			"/assets/badge-D_4MQwiV.js"
		]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-C041y8jP.js",
			"/assets/codes-rKjzhTrl.js",
			"/assets/card-DCgkpyd6.js"
		]
	},
	"/create": {
		filePath: "/workspace/src/routes/create.tsx",
		children: void 0,
		preloads: [
			"/assets/create-CUlf8p-3.js",
			"/assets/codes-rKjzhTrl.js",
			"/assets/dist-CZhufjEE.js",
			"/assets/copy-CAyw5dhc.js",
			"/assets/download-DgFt_HG3.js",
			"/assets/card-DCgkpyd6.js",
			"/assets/render-DDRfgRkN.js",
			"/assets/qr-preview-C0SVi_yC.js",
			"/assets/types-CpXr79mB.js",
			"/assets/guest-store-Bpu3hbT3.js",
			"/assets/input-DGfeEbj3.js",
			"/assets/label-DISuwHZD.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-gp7lrgKP.js",
			"/assets/card-DCgkpyd6.js",
			"/assets/input-DGfeEbj3.js",
			"/assets/label-DISuwHZD.js"
		]
	},
	"/pricing": {
		filePath: "/workspace/src/routes/pricing.tsx",
		children: void 0,
		preloads: ["/assets/pricing-ChQlFTE4.js", "/assets/badge-D_4MQwiV.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DUu0NZLb.js"]
	},
	"/scan": {
		filePath: "/workspace/src/routes/scan.tsx",
		children: void 0,
		preloads: [
			"/assets/scan-Bbfjwc2X.js",
			"/assets/copy-CAyw5dhc.js",
			"/assets/card-DCgkpyd6.js",
			"/assets/badge-D_4MQwiV.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-XXwuzcYe.js"]
	},
	"/library/$id": {
		filePath: "/workspace/src/routes/library/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-Bv2GCrZE.js",
			"/assets/codes-rKjzhTrl.js",
			"/assets/download-DgFt_HG3.js",
			"/assets/useQuery-BCLgEaK9.js",
			"/assets/render-DDRfgRkN.js",
			"/assets/qr-preview-C0SVi_yC.js",
			"/assets/guest-store-Bpu3hbT3.js",
			"/assets/input-DGfeEbj3.js",
			"/assets/label-DISuwHZD.js",
			"/assets/badge-D_4MQwiV.js"
		]
	},
	"/library/": {
		filePath: "/workspace/src/routes/library/index.tsx",
		children: void 0,
		preloads: [
			"/assets/library-BcL4euMg.js",
			"/assets/codes-rKjzhTrl.js",
			"/assets/dist-CZhufjEE.js",
			"/assets/useQuery-BCLgEaK9.js",
			"/assets/render-DDRfgRkN.js",
			"/assets/types-CpXr79mB.js",
			"/assets/guest-store-Bpu3hbT3.js",
			"/assets/input-DGfeEbj3.js",
			"/assets/badge-D_4MQwiV.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
