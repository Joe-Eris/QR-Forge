import { writeFileSync } from "node:fs";
import { chromium } from "playwright";
import { renderSVG } from "uqr";

const qrSvg = renderSVG("https://qrforge.app", {
  ecc: "M",
  border: 2,
  pixelSize: 10,
  whiteColor: "#FFFBF5",
  blackColor: "#1C1916",
});

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>QRForge</title>
<style>
  @font-face {
    font-family: "LibSerif";
    src: url("file:///usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf") format("truetype");
    font-weight: 700;
    font-style: normal;
  }
  @font-face {
    font-family: "LibSerif";
    src: url("file:///usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf") format("truetype");
    font-weight: 400;
    font-style: italic;
  }
  html, body {
    margin: 0;
    padding: 0;
    width: 1200px;
    height: 630px;
    background: #F4F1EA;
  }
  .artboard {
    position: relative;
    width: 1200px;
    height: 630px;
    overflow: hidden;
    background:
      radial-gradient(1100px 640px at 48% 42%, #FFF8EE 0%, #F4F1EA 58%, #EBE6DA 100%);
  }
  .grain {
    position: absolute;
    inset: 0;
    width: 1200px;
    height: 630px;
    pointer-events: none;
    mix-blend-mode: multiply;
    opacity: 0.18;
  }
  .row {
    position: relative;
    z-index: 1;
    height: 630px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 72px;
    padding: 0 96px;
    box-sizing: border-box;
  }
  .copy { flex: 0 1 auto; max-width: 540px; }
  .mark {
    width: 34px;
    height: 34px;
    margin: 0 0 26px;
    display: block;
  }
  h1 {
    margin: 0;
    font-family: LibSerif, "Liberation Serif", serif;
    font-weight: 700;
    font-size: 108px;
    line-height: 0.9;
    letter-spacing: -0.034em;
    color: #1C1916;
  }
  .rule {
    width: 52px;
    height: 3px;
    background: #0369A1;
    margin: 24px 0 18px;
    border-radius: 1px;
  }
  .tag {
    margin: 0;
    font-family: LibSerif, "Liberation Serif", serif;
    font-weight: 400;
    font-style: italic;
    font-size: 28px;
    line-height: 1.3;
    color: #1C1916;
    opacity: 0.84;
    letter-spacing: -0.01em;
  }
  .plate {
    flex: 0 0 auto;
    background: #FFFBF5;
    padding: 30px;
    border-radius: 8px;
    box-shadow:
      0 1px 0 rgba(28, 25, 22, 0.05),
      0 24px 54px rgba(28, 25, 22, 0.13);
    outline: 1px solid rgba(28, 25, 22, 0.08);
  }
  .plate svg {
    display: block;
    width: 336px;
    height: 336px;
  }
  .crop {
    position: absolute;
    width: 20px;
    height: 20px;
    pointer-events: none;
    z-index: 2;
  }
  .crop::before,
  .crop::after {
    content: "";
    position: absolute;
    background: #1C1916;
    opacity: 0.2;
  }
  .crop::before { width: 20px; height: 1px; }
  .crop::after { width: 1px; height: 20px; }
  .tl { top: 34px; left: 34px; }
  .tr { top: 34px; right: 34px; }
  .tr::before { right: 0; left: auto; }
  .tr::after { right: 0; left: auto; }
  .bl { bottom: 34px; left: 34px; }
  .bl::after { bottom: 0; top: auto; }
  .br { bottom: 34px; right: 34px; }
  .br::before { right: 0; left: auto; }
  .br::after { right: 0; left: auto; bottom: 0; top: auto; }
</style>
</head>
<body>
  <div class="artboard">
    <svg class="grain" xmlns="http://www.w3.org/2000/svg" width="1200" height="630">
      <filter id="n" x="0" y="0" width="100%" height="100%">
        <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="4" seed="11" stitchTiles="stitch"/>
        <feColorMatrix type="saturate" values="0"/>
      </filter>
      <rect width="1200" height="630" filter="url(#n)"/>
    </svg>
    <span class="crop tl"></span>
    <span class="crop tr"></span>
    <span class="crop bl"></span>
    <span class="crop br"></span>
    <div class="row">
      <div class="copy">
        <svg class="mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true">
          <g transform="translate(2.5 2.5)">
            <rect width="27" height="27" fill="#0369A1"/>
            <rect x="3.86" y="3.86" width="19.28" height="19.28" fill="#F4F1EA"/>
            <rect x="7.72" y="7.72" width="11.56" height="11.56" fill="#0369A1"/>
          </g>
        </svg>
        <h1>QRForge</h1>
        <div class="rule"></div>
        <p class="tag">QR codes without the junk.</p>
      </div>
      <div class="plate">${qrSvg}</div>
    </div>
  </div>
</body>
</html>
`;

writeFileSync("/workspace/.grok/og-card.html", html);

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1200, height: 630 },
    deviceScaleFactor: 2,
  });
  await page.goto("file:///workspace/.grok/og-card.html", {
    waitUntil: "load",
    timeout: 15000,
  });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(200);
  await page.screenshot({
    path: "/workspace/.grok/og-card-raw.png",
    type: "png",
    fullPage: false,
  });
} finally {
  await browser.close();
}

console.log("wrote /workspace/.grok/og-card-raw.png");
