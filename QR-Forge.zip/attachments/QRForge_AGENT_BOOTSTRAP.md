# QRForge — Agent Bootstrap (v1.1)

Paste the **Master Prompt** into any coding agent. Give the agent this file plus the PRD Word document.

## Master prompt

You are the implementing engineer for QRForge. Read the QRForge PRD + Agent Build Format v1.1 and execute it. Phase 1 only unless I say Phase 2.

1. Install everything in the install pack using pnpm, Docker Postgres, shadcn, qr-core, and tests. Do not ask me to install tools you can install yourself.
2. Build the frontend: landing, `/create` workspace, `/scan`, `/library`, `/login`, legal pages. A guest can generate and download PNG/SVG with no account.
3. Build the backend: auth, Postgres codes CRUD, guest-history merge, rate limits.
4. Build promotion: landing copy, SEO/OG, sitemap, `docs/launch` kit.
5. Use one encoder for preview and files. Payload types: URL, TEXT, WIFI, VCARD, EMAIL, SMS, TEL, GEO. Enforce quiet zone ≥ 4, contrast gate, logo rules. Never log payloads.
6. Map every FR-ID to `IMPLEMENTATION.md`. After each wave run typecheck, unit tests, and relevant e2e. Stop at Phase 1 Definition of Done.

## Host preflight

- Node.js 22 LTS (20+ OK)
- Git
- Docker Engine + Compose v2 (or local PostgreSQL 16)
- Enable pnpm: `corepack enable && corepack prepare pnpm@10 --activate`

## Wave 0 commands (non-interactive, in order)

```bash
mkdir -p qrforge && cd qrforge
pnpm init
# set package.json "private": true and workspaces: ["apps/*","packages/*"]

cat > pnpm-workspace.yaml << 'EOF'
packages:
  - "apps/*"
  - "packages/*"
EOF

pnpm create next-app@latest apps/web --typescript --tailwind --eslint --app --src-dir false --import-alias "@/*" --use-pnpm

mkdir -p packages/qr-core/src packages/qr-decode/src infra docs/launch

cd apps/web
pnpm dlx shadcn@latest init -y
pnpm dlx shadcn@latest add button input label select tabs dialog dropdown-menu tooltip card badge separator sheet accordion sonner

pnpm add zod react-hook-form @hookform/resolvers @tanstack/react-query lucide-react next-themes clsx tailwind-merge class-variance-authority sonner nanoid next-auth@beta @prisma/client @node-rs/argon2 uqr jsqr
pnpm add -D prisma vitest @vitejs/plugin-react playwright @playwright/test @testing-library/react @testing-library/user-event jsdom
pnpm exec playwright install --with-deps
```

## Docker Postgres

`infra/docker-compose.yml`:

```yaml
services:
  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: qrforge
      POSTGRES_PASSWORD: qrforge
      POSTGRES_DB: qrforge
    ports:
      - "5432:5432"
    volumes:
      - qrforge_pg:/var/lib/postgresql/data
volumes:
  qrforge_pg:
```

```bash
docker compose -f infra/docker-compose.yml up -d
```

## .env.example

```
NEXT_PUBLIC_APP_NAME=QRForge
NEXT_PUBLIC_APP_URL=http://localhost:3000
DATABASE_URL=postgresql://qrforge:qrforge@localhost:5432/qrforge
AUTH_SECRET=replace-with-32-plus-random-bytes
AUTH_URL=http://localhost:3000
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
EMAIL_FROM=noreply@localhost
AUTH_GOOGLE_ID=
AUTH_GOOGLE_SECRET=
S3_ENDPOINT=
S3_BUCKET=qrforge
S3_ACCESS_KEY=
S3_SECRET_KEY=
```

## Verify

```bash
pnpm typecheck
pnpm test
pnpm dev
# curl -sI http://localhost:3000  → 200
```

## Phase 1 routes that must exist

`/  /create  /scan  /library  /library/[id]  /login  /account  /pricing  /privacy  /terms`

## Do not build in Phase 1

Dynamic `/r/:code`, analytics dashboards, public API keys, Stripe, teams/SSO, batch CSV.
